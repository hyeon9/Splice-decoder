#!/bin/bash
#SBATCH -c 5
#SBATCH -q batch
#SBATCH --mem=250G
#SBATCH -o ./%u-%x-%j
#SBATCH -e ./%u-%x-%j.err
#SBATCH --time=36:00:00

source /home/kangh/lab-server/miniforge-pypy3/bin/activate base
conda activate hg-py3

wig2bed < /home/kangh/lab-server/Tool/Splice-decoder_git/dat/hg38.phastCons100way.wig > /home/kangh/lab-server/Tool/Splice-decoder_git/dat/hg38.phastCons100way.bed
